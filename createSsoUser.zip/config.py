import boto3
import json
import urllib3
import traceback
import os
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

http = urllib3.PoolManager()
identitystore = boto3.client('identitystore')

def send_response(event, context, response_status, response_data,physical_resource_id):
    response_url = event['ResponseURL']
    response_body = {
        'Status': response_status,
        'Reason': f'See details in CloudWatch Log Stream: {context.log_stream_name}',
        'PhysicalResourceId': physical_resource_id or context.log_stream_name,
        'StackId': event['StackId'],
        'RequestId': event['RequestId'],
        'LogicalResourceId': event['LogicalResourceId'],
        'Data': response_data
    }

    encoded_body = json.dumps(response_body).encode("utf-8")
    headers = {'content-type': '', 'content-length': str(len(encoded_body))}
    try:
        http.request('PUT', response_url, body=encoded_body, headers=headers)
    except Exception as e:
        logger.error(f"Failed to send response: {str(e)}")


def get_user_id(identity_store_id, username):
    response = identitystore.list_users(
        IdentityStoreId=identity_store_id,
        Filters=[{
            'AttributePath': 'UserName',
            'AttributeValue': username
        }]
    )
    if response['Users']:
        return response['Users'][0]['UserId']
    return None

def get_group_id(identity_store_id, group_name):
    group_response = identitystore.list_groups(
        IdentityStoreId=identity_store_id,
        Filters=[{
            'AttributePath': 'DisplayName',
            'AttributeValue': group_name
        }]
    )
    groups = group_response.get('Groups', [])
    if not groups:
        raise Exception(f"No group found with name {group_name}")
    return groups[0]['GroupId']

def get_existing_memberships(identity_store_id, group_id):
    existing_members = []
    next_token = None
    while True:
        params = {
            'IdentityStoreId': identity_store_id,
            'GroupId': group_id
        }
        if next_token:
            params['NextToken'] = next_token
            
        response = identitystore.list_group_memberships(**params)
        existing_members.extend(response['GroupMemberships'])
        next_token = response.get('NextToken')
        if not next_token:
            break
    return {m['MemberId']['UserId']: m['MembershipId'] for m in existing_members}

def get_existing_application_assignments(sso_admin_client, group_id, application_arn):
    """Get existing application assignments for a group"""
    try:
        response = sso_admin_client.list_application_assignments(
            ApplicationArn=application_arn
        )
        return [a for a in response.get('ApplicationAssignments', []) 
               if a['PrincipalType'] == 'GROUP' and a['PrincipalId'] == group_id]
    except Exception as e:
        logger.error(f"Error listing application assignments: {str(e)}")
        return []

def remove_user_from_group(identity_store_id, membership_id):
    identitystore.delete_group_membership(
        IdentityStoreId=identity_store_id,
        MembershipId=membership_id
    )

def delete_user(identity_store_id, user_id):
    identitystore.delete_user(
        IdentityStoreId=identity_store_id,
        UserId=user_id
    )

def add_user_to_group(identity_store_id, user_id, group_id):
    identitystore.create_group_membership(
        IdentityStoreId=identity_store_id,
        GroupId=group_id,
        MemberId={'UserId': user_id}
    )

def list_user_group_memberships(identity_store_id, user_id):
    memberships = []
    paginator = identitystore.get_paginator('list_group_memberships_for_member')
    for page in paginator.paginate(
        IdentityStoreId=identity_store_id,
        MemberId={'UserId': user_id}
    ):
        memberships.extend(page['GroupMemberships'])
    return memberships

