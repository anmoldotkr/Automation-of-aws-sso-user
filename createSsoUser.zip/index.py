import json
import boto3
import urllib3
import os
import logging

from config import get_group_id,add_user_to_group,send_response,get_user_id,list_user_group_memberships,remove_user_from_group,delete_user

# confgiuring logging 
logger = logging.getLogger()
logger.setLevel(logging.INFO)

identitystore_client = boto3.client('identitystore')
http = urllib3.PoolManager()


def handler(event, context):

    logger.info(f"Received events: {json.dumps(event)}")
    props = event['ResourceProperties']
    identity_store_id = props['IdentityStoreId']
    username = props['UserName']
    group_names = props.get('GroupName', [])

    try:
        if event['RequestType'] == 'Create':
            logger.info(f"-----Creating user-------")
            response = identitystore_client.create_user(
                IdentityStoreId=identity_store_id,
                UserName=username,
                Name={'GivenName': props['FirstName'], 'FamilyName': props['LastName']},
                DisplayName=props['DisplayName'],
                Emails=[{'Value': props['UserEmail'], 'Type': 'work', 'Primary': True}]
            )
            user_id = response['UserId']
            logger.info(f"User created: {user_id}")

            for group_name in group_names:
                group_id = get_group_id(identity_store_id, group_name)
                add_user_to_group(identity_store_id, user_id, group_id)
                logger.info(f"Added to group: {group_name} (ID: {group_id})")

            send_response(event, context, "SUCCESS", {"PhysicalResourceId": user_id},user_id)

        elif event['RequestType'] == 'Update':
            logger.info(f"Updating user group memberships...")
            user_id = get_user_id(identity_store_id, username)
            if not user_id:
                raise Exception(f"User '{username}' not found")
            
            # Get current memberships with group info
            current_memberships = []
            current_group_ids = set()
            for membership in list_user_group_memberships(identity_store_id, user_id):
                group_info = identitystore_client.describe_group_membership(
                    IdentityStoreId=identity_store_id,
                    MembershipId=membership['MembershipId']
                )
                current_memberships.append({
                    'membership_id': membership['MembershipId'],
                    'group_id': group_info['GroupId']
                })
                current_group_ids.add(group_info['GroupId'])
            
            # Get desired group IDs
            desired_group_ids = set(get_group_id(identity_store_id, name) for name in group_names)
            
            logger.info(f"Current groups: {current_group_ids}")
            logger.info(f"Desired groups: {desired_group_ids}")

            # Add to new groups
            for group_id in desired_group_ids - current_group_ids:
                add_user_to_group(identity_store_id, user_id, group_id)
                logger.info(f"Added to group: {group_id}")

            # Remove from old groups
            for membership in current_memberships:
                if membership['group_id'] not in desired_group_ids:
                    remove_user_from_group(identity_store_id, membership['membership_id'])
                    logger.info(f"Removed from group: {membership['group_id']}")

            send_response(event, context, "SUCCESS", {"PhysicalResourceId": user_id},user_id)

        elif event['RequestType'] == 'Delete':
            logger.info(f"Cleaning up user and groups...")
            user_id = get_user_id(identity_store_id, username)
            if user_id:
                memberships = list_user_group_memberships(identity_store_id, user_id)
                for membership in memberships:
                    remove_user_from_group(identity_store_id, membership['MembershipId'])
                    logger.info(f"Removed from group: {membership['GroupId']}")
                delete_user(identity_store_id, user_id)
                logger.info(f"User deleted: {user_id}")
                send_response(event, context, "SUCCESS", {"PhysicalResourceId": user_id},user_id)
            else:
                logger.info(f"User not found during delete.")
                send_response(event, context, "SUCCESS", {"PhysicalResourceId": "user-not-found"},user_id)

    except Exception as e:
        logger.info(f"Exception: {e}")
        send_response(event, context, "FAILED", {"Message": str(e), "PhysicalResourceId": "custom-resource-failed"},None)
