import boto3
import json
import urllib3
import traceback
import logging

from config import send_response,get_group_id,get_user_id,get_existing_memberships
# confgiuring logging 
logger = logging.getLogger()
logger.setLevel(logging.INFO)

http = urllib3.PoolManager()
identitystore = boto3.client('identitystore')

def handler(event, context):
    # logger.info(f"Received event: {json.dumps(event)}")
    logger.info(f"ResponseURL: {event['ResponseURL']}")

    request_type = event['RequestType']
    props = event['ResourceProperties']
    old_props = event.get('OldResourceProperties', {})

    identity_store_id = props['IdentityStoreId']
    group_name = props['GroupName']
    operation = props.get('Operation', 'add')
    usernames = set(props['Usernames'])

    try:
        group_id = get_group_id(identity_store_id, group_name)
        
        # Get current user IDs for the requested usernames
        current_user_ids = {}
        for username in usernames:
            try:
                current_user_ids[username] = get_user_id(identity_store_id, username)
            except Exception as e:
                logger.info(f"Warning: {str(e)}")
                continue  # Skip users that don't exist

        if not current_user_ids:
            raise Exception("None of the specified usernames exist in the identity store")

        # Get existing group memberships
        existing_members = get_existing_memberships(identity_store_id, group_id)
        existing_user_ids = set(existing_members.keys())
        requested_user_ids = set(current_user_ids.values())

        if request_type == 'Create' or request_type == 'Update':
            if operation == 'add':
                # Add users that aren't already in the group
                to_add = requested_user_ids - existing_user_ids
                
                for user_id in to_add:
                    try:
                        identitystore.create_group_membership(
                            IdentityStoreId=identity_store_id,
                            GroupId=group_id,
                            MemberId={'UserId': user_id}
                        )
                    except Exception as e:
                        logger.info(f"Warning: Failed to add user {user_id} to group: {str(e)}")
                        continue
                
                send_response(event, context, 'SUCCESS', {
                    'GroupId': group_id,
                    'AddedUsers': list(to_add),
                    'TotalMembers': len(existing_user_ids) + len(to_add),
                    'Note': f'Added {len(to_add)} users to the group'
                }, physical_resource_id=group_id)
                
            elif operation == 'remove':
                # Remove users that are in the group
                to_remove = requested_user_ids & existing_user_ids
                
                for user_id in to_remove:
                    try:
                        identitystore.delete_group_membership(
                            IdentityStoreId=identity_store_id,
                            MembershipId=existing_members[user_id]
                        )
                    except Exception as e:
                        logger.info(f"Warning: Failed to remove user {user_id} from group: {str(e)}")
                        continue
                
                send_response(event, context, 'SUCCESS', {
                    'GroupId': group_id,
                    'RemovedUsers': list(to_remove),
                    'TotalMembers': len(existing_user_ids) - len(to_remove),
                    'Note': f'Removed {len(to_remove)} users from the group'
                }, physical_resource_id=group_id)
                
            else:
                send_response(event, context, 'FAILED', {}, reason=f"Invalid operation: {operation}")
                
        elif request_type == 'Delete':
            # Only remove the users that were specified in this CFN resource
            existing_members = get_existing_memberships(identity_store_id, group_id)
            removed_count = 0
            
            # Get the user IDs that were specified in this resource
            specified_user_ids = set()
            for username in usernames:
                try:
                    user_id = get_user_id(identity_store_id, username)
                    specified_user_ids.add(user_id)
                except Exception:
                    continue  # Skip users that don't exist
            
            # Remove only the specified users' memberships
            for user_id, membership_id in existing_members.items():
                if user_id in specified_user_ids:
                    try:
                        identitystore.delete_group_membership(
                            IdentityStoreId=identity_store_id,
                            MembershipId=membership_id
                        )
                        removed_count += 1
                    except Exception as e:
                        logger.info(f"Warning: Failed to remove membership for user {user_id}: {str(e)}")
                        continue
            
            send_response(event, context, 'SUCCESS', {
                'Message': f'Removed {removed_count} specified users from group during deletion',
                'GroupId': group_id,
                'RemovedUsers': list(specified_user_ids)
            }, physical_resource_id=group_id)
        else:
            send_response(event, context, 'FAILED', {}, reason=f"Unsupported request type: {request_type}")

    except Exception as e:
        logger.info(f"Exception occurred: {str(e)}")
        traceback.print_exc()
        send_response(event, context, 'FAILED', {}, reason=str(e))
