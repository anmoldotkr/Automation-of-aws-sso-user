import boto3
import json
import urllib3
import logging


from config import get_existing_application_assignments,send_response

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

http = urllib3.PoolManager()

def handler(event, context):
    logger.info(f"Received event: {json.dumps(event)}")
    
    try:
        request_type = event['RequestType']
        props = event['ResourceProperties']
        group_name = props['GroupName']
        permission_set_arn = props['PermissionSetArn']
        identity_store_id = props['IdentityStoreId']
        instance_arn = props['InstanceArn']
        account_ids = props.get('AccountIds', [])
        application_arns = props.get('ApplicationArns', [])
        
        identitystore = boto3.client('identitystore')
        sso_admin = boto3.client('sso-admin')

        if request_type == 'Create':
            # Create SSO group
            group = identitystore.create_group(
                IdentityStoreId=identity_store_id,
                DisplayName=group_name,
                Description=f"Created by CloudFormation {event['StackId']}"
            )
            group_id = group['GroupId']
            logger.info(f"Created group {group_id}")

            # Process account assignments
            for account_id in account_ids:
                try:
                    sso_admin.create_account_assignment(
                        InstanceArn=instance_arn,
                        TargetId=account_id,
                        TargetType='AWS_ACCOUNT',
                        PermissionSetArn=permission_set_arn,
                        PrincipalType='GROUP',
                        PrincipalId=group_id
                    )
                    logger.info(f"Assigned account {account_id} to group")
                except Exception as e:
                    logger.error(f"Failed to assign account {account_id}: {str(e)}")

            # Process application assignments
            for app_arn in application_arns:
                try:
                    existing = get_existing_application_assignments(sso_admin, group_id, app_arn)
                    if not existing:
                        sso_admin.create_application_assignment(
                            ApplicationArn=app_arn,
                            PrincipalType='GROUP',
                            PrincipalId=group_id
                        )
                        logger.info(f"Assigned application {app_arn} to group")
                except Exception as e:
                    logger.error(f"Failed to assign application {app_arn}: {str(e)}")

            send_response(event, context, 'SUCCESS', {'GroupId': group_id}, group_id)

        elif request_type == 'Delete':
            group_id = event['PhysicalResourceId']
            old_props = event.get('OldResourceProperties', {})
            old_account_ids = old_props.get('AccountIds', [])
            old_app_arns = old_props.get('ApplicationArns', [])

            # Remove account assignments
            for account_id in old_account_ids:
                try:
                    sso_admin.delete_account_assignment(
                        InstanceArn=instance_arn,
                        TargetId=account_id,
                        TargetType='AWS_ACCOUNT',
                        PermissionSetArn=permission_set_arn,
                        PrincipalType='GROUP',
                        PrincipalId=group_id
                    )
                    logger.info(f"Removed account {account_id} from group")
                except Exception as e:
                    logger.error(f"Failed to remove account {account_id}: {str(e)}")

            # Remove application assignments
            for app_arn in old_app_arns:
                try:
                    assignments = get_existing_application_assignments(sso_admin, group_id, app_arn)
                    for assignment in assignments:
                        sso_admin.delete_application_assignment(
                            ApplicationArn=app_arn,
                            PrincipalType='GROUP',
                            PrincipalId=group_id
                        )
                        logger.info(f"Removed application {app_arn} from group")
                except Exception as e:
                    logger.error(f"Failed to remove application {app_arn}: {str(e)}")

            # Delete the group
            try:
                identitystore.delete_group(
                    IdentityStoreId=identity_store_id,
                    GroupId=group_id
                )
                logger.info(f"Deleted group {group_id}")
            except Exception as e:
                logger.error(f"Failed to delete group: {str(e)}")

            send_response(event, context, 'SUCCESS', {}, group_id)

        elif request_type == 'Update':
            group_id = event['PhysicalResourceId']
            old_props = event.get('OldResourceProperties', {})
            
            # Handle account assignments
            old_accounts = set(old_props.get('AccountIds', []))
            new_accounts = set(account_ids)
            
            # Add new account assignments
            for account_id in new_accounts - old_accounts:
                try:
                    sso_admin.create_account_assignment(
                        InstanceArn=instance_arn,
                        TargetId=account_id,
                        TargetType='AWS_ACCOUNT',
                        PermissionSetArn=permission_set_arn,
                        PrincipalType='GROUP',
                        PrincipalId=group_id
                    )
                    logger.info(f"Added new account assignment {account_id}")
                except Exception as e:
                    logger.error(f"Failed to add account {account_id}: {str(e)}")

            # Remove old account assignments
            for account_id in old_accounts - new_accounts:
                try:
                    sso_admin.delete_account_assignment(
                        InstanceArn=instance_arn,
                        TargetId=account_id,
                        TargetType='AWS_ACCOUNT',
                        PermissionSetArn=permission_set_arn,
                        PrincipalType='GROUP',
                        PrincipalId=group_id
                    )
                    logger.info(f"Removed old account assignment {account_id}")
                except Exception as e:
                    logger.error(f"Failed to remove account {account_id}: {str(e)}")

            # Handle application assignments
            old_apps = set(old_props.get('ApplicationArns', []))
            new_apps = set(application_arns)
            
            # Add new application assignments
            for app_arn in new_apps - old_apps:
                try:
                    existing = get_existing_application_assignments(sso_admin, group_id, app_arn)
                    if not existing:
                        sso_admin.create_application_assignment(
                            ApplicationArn=app_arn,
                            PrincipalType='GROUP',
                            PrincipalId=group_id
                        )
                        logger.info(f"Added new application assignment {app_arn}")
                except Exception as e:
                    logger.error(f"Failed to add application {app_arn}: {str(e)}")

            # Remove old application assignments
            for app_arn in old_apps - new_apps:
                try:
                    assignments = get_existing_application_assignments(sso_admin, group_id, app_arn)
                    for assignment in assignments:
                        sso_admin.delete_application_assignment(
                            ApplicationArn=app_arn,
                            PrincipalType='GROUP',
                            PrincipalId=group_id
                        )
                        logger.info(f"Removed old application assignment {app_arn}")
                except Exception as e:
                    logger.error(f"Failed to remove application {app_arn}: {str(e)}")

            send_response(event, context, 'SUCCESS', {'GroupId': group_id}, group_id)

    except Exception as e:
        logger.error(f"Handler error: {str(e)}")
        send_response(event, context, 'FAILED', {'Error': str(e)}, None)
